// SPDX-License-Identifier: GPL-2.0-or-later

pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls as Controls
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.notificationmanager as NotificationManager
import org.kde.plasma.components as PlasmaComponents
import org.kde.ksvg as KSvg
import ".." as Components
import "../punchimenu" as PunchiMenuComponents
import "ControlCenterRevealMetrics.js" as RevealMetrics

FocusScope {
    id: root

    required property var controller
    property var themeAdapter: null
    property var nightLightAdapter: null
    property var volumeOsdAdapter: null
    property string presentationMode: "fullScreen"
    property real viewportWidth: width
    property real viewportHeight: height
    property real themeFrameLeftMargin: 0
    property real themeFrameTopMargin: 0
    property real themeFrameRightMargin: 0
    property real themeFrameBottomMargin: 0
    property real floatingBackgroundOpacity: 0.75
    property bool controlCenterOpen: false
    property string pendingSettingsSection: ""
    property string pendingApplicationAction: ""
    property string currentPage: "home"
    // State of the inline Wi-Fi submenu. It belongs here because Escape, the page
    // transitions and the activation errors all have to agree on it.
    property bool networkSubmenuOpen: false
    property string networkErrorMessage: ""
    property bool showVirtualAudioDevices: false

    // The Plasma style collapses the theme durations to the animator minimum
    // when the user reduces or disables animations, so comparing against that
    // minimum is the only criterion here that can actually become false. A
    // comparison against zero never did; see
    // docs/Referencias/referencia-motion-plasma-qt.md.
    readonly property bool motionEnabled: Kirigami.Units.longDuration > 1
    readonly property bool floatingMode: presentationMode === "floating"
    readonly property real safeFloatingBackgroundOpacity: {
        const requestedOpacity = Number(floatingBackgroundOpacity)
        return Number.isFinite(requestedOpacity)
            ? Math.max(0.50, Math.min(1.0, requestedOpacity))
            : 0.75
    }
    readonly property real nativeFrameThickness: 2
    readonly property real themeFrameOverlapLeft: Math.max(0,
        finiteNonNegative(themeFrameLeftMargin) - nativeFrameThickness)
    readonly property real themeFrameOverlapTop: Math.max(0,
        finiteNonNegative(themeFrameTopMargin) - nativeFrameThickness)
    readonly property real themeFrameOverlapRight: Math.max(0,
        finiteNonNegative(themeFrameRightMargin) - nativeFrameThickness)
    readonly property real themeFrameOverlapBottom: Math.max(0,
        finiteNonNegative(themeFrameBottomMargin) - nativeFrameThickness)
    readonly property var backgroundBlurMaskSource: floatingBackground
    readonly property point backgroundBlurMaskOffset:
        mappedSurfaceGeometry.backgroundMaskOffset
    readonly property int animOpenDuration:
        Math.round(Kirigami.Units.longDuration * 1.1)
    readonly property int animCloseDuration: motionEnabled
        ? Math.max(1, Math.round(Kirigami.Units.shortDuration * 1.4))
        : 1
    // One progress driver for the whole surface. Opacity, scale and travel are
    // derived from it, so the entrance has a single origin instead of stacking
    // independent animators that can disagree with each other.
    property real revealProgress: controlCenterOpen ? 1.0 : 0.0
    // The floating panel is docked to the top-right corner of the screen, so it
    // grows out of that corner instead of drifting across the surface it sits on.
    readonly property int revealOrigin: Item.TopRight
    // 6 % reads as a reveal without re-rastering text at a different size. Zero
    // would turn the entrance back into a plain cross-fade.
    readonly property real revealScaleDelta: 0.06
    readonly property int unreadNotificationCount:
        Math.max(0, notificationHistory.unreadNotificationsCount)
    readonly property bool doNotDisturbActive:
        NotificationManager.Server.valid
        && NotificationManager.Server.inhibited
    readonly property bool providersActive: visible
    readonly property var volumeAdapter: volumeProvider.status === Loader.Ready
        ? volumeProvider.item : null
    readonly property var brightnessAdapter:
        brightnessProvider.status === Loader.Ready
        ? brightnessProvider.item : null
    readonly property var networkAdapter: networkProvider.status === Loader.Ready
        ? networkProvider.item : null
    readonly property var bluetoothAdapter:
        bluetoothProvider.status === Loader.Ready
        ? bluetoothProvider.item : null
    readonly property ControlCenterNetworkPage networkPage:
        networkPageLoader.item as ControlCenterNetworkPage
    readonly property var bluetoothPage: bluetoothPageLoader.item
    readonly property var audioPage: audioPageLoader.item

    signal closeFinished()

    objectName: "controlCenterOverlay"
    visible: controlCenterOpen || revealProgress > 0.001
        || fullscreenBackdrop.opacity > 0.01
    enabled: controlCenterOpen
    Keys.onEscapePressed: handleEscape()

    // The submenu only belongs to the home page: leaving it closes the section, so
    // the page that arrives never overlaps a reveal that is still open.
    onCurrentPageChanged: {
        if (currentPage !== "home") {
            networkSubmenuOpen = false
        }
    }

    onNetworkAdapterChanged: {
        if (!networkAdapter) {
            networkSubmenuOpen = false
            networkErrorMessage = ""
        }
    }

    // Single animator of the surface. A zero duration can leave an animator
    // unstarted, so the reduce-motion path disables it and jumps to the final
    // value instead; the close timer keeps ownership of the sequencing either
    // way. See docs/Referencias/referencia-motion-plasma-qt.md.
    Behavior on revealProgress {
        enabled: root.motionEnabled
        NumberAnimation {
            duration: root.controlCenterOpen
                ? root.animOpenDuration : root.animCloseDuration
            easing.type: root.controlCenterOpen
                ? Easing.OutCubic : Easing.InCubic
        }
    }

    NotificationManager.Notifications {
        id: notificationHistory

        showExpired: true
        showDismissed: true
        showJobs: false
        sortMode: NotificationManager.Notifications.SortByDate
        groupMode: NotificationManager.Notifications.GroupDisabled
        urgencies: NotificationManager.Notifications.LowUrgency
            | NotificationManager.Notifications.NormalUrgency
            | NotificationManager.Notifications.CriticalUrgency
    }

    NotificationManager.Settings {
        id: notificationSettings
    }

    function finiteNonNegative(value) {
        const numericValue = Number(value)
        return Number.isFinite(numericValue)
            ? Math.max(0, numericValue) : 0
    }

    Loader {
        id: volumeProvider
        active: root.providersActive
        asynchronous: false
        source: Qt.resolvedUrl("ControlCenterVolumeAdapter.qml")
        onLoaded: item.showVirtualDevices = root.showVirtualAudioDevices
    }

    onShowVirtualAudioDevicesChanged: {
        if (root.volumeAdapter) {
            root.volumeAdapter.showVirtualDevices =
                root.showVirtualAudioDevices
        }
    }

    Loader {
        id: brightnessProvider
        active: root.providersActive
        asynchronous: false
        source: Qt.resolvedUrl("ControlCenterBrightnessAdapter.qml")
    }

    Loader {
        id: networkProvider
        active: root.providersActive
        asynchronous: false
        source: Qt.resolvedUrl("ControlCenterNetworkAdapter.qml")
    }

    Loader {
        id: bluetoothProvider
        active: root.providersActive
        asynchronous: false
        source: Qt.resolvedUrl("ControlCenterBluetoothAdapter.qml")
    }

    function openOverlay() {
        closeTimer.stop()
        pendingSettingsSection = ""
        pendingApplicationAction = ""
        currentPage = "home"
        networkSubmenuOpen = false
        networkErrorMessage = ""
        if (root.nightLightAdapter) {
            root.nightLightAdapter.refresh()
        }
        if (root.volumeOsdAdapter) {
            root.volumeOsdAdapter.refresh()
        }
        controlCenterOpen = true
        root.forceActiveFocus()
        Qt.callLater(function() {
            if (root.controlCenterOpen) {
                homePage.focusFirstControl()
            }
        })
    }

    // Moves focus to the page that finished expanding. The page that is leaving
    // stays disabled while it compresses, so keyboard focus and assistive
    // technology always land on the page that is actually visible.
    function settlePage(pageName) {
        if (!root.controlCenterOpen || root.currentPage !== pageName) {
            return
        }
        const target = pageName === "network" ? root.networkPage
            : pageName === "bluetooth" ? root.bluetoothPage
                : pageName === "sound" ? root.audioPage : homePage
        if (target && typeof target.focusFirstControl === "function") {
            target.focusFirstControl()
        }
    }

    function showNetworkPage() {
        if (!networkAdapter) {
            requestSettings("network")
            return
        }
        currentPage = "network"
    }

    function showBluetoothPage() {
        if (!bluetoothAdapter) {
            requestSettings("bluetooth")
            return
        }
        currentPage = "bluetooth"
    }

    function showSoundPage() {
        if (!volumeAdapter) {
            requestSettings("sound")
            return
        }
        currentPage = "sound"
    }

    function showHomePage() {
        currentPage = "home"
    }

    function handleEscape() {
        if (passwordSurface.active) {
            passwordSurface.closeAndClear()
        } else if (root.networkSubmenuOpen) {
            // The row that opened the submenu is the control that closes it, so
            // Escape collapses the section instead of leaving the page.
            homePage.networkKeyboardEntry = true
            root.networkSubmenuOpen = false
        } else if (currentPage === "network"
                || currentPage === "bluetooth"
                || currentPage === "sound") {
            showHomePage()
        } else {
            forceClose()
        }
    }

    function toggleDoNotDisturb() {
        if (!NotificationManager.Server.valid) {
            return
        }

        if (root.doNotDisturbActive) {
            notificationSettings.notificationsInhibitedUntil = undefined
            if (typeof notificationSettings.revokeApplicationInhibitions
                    === "function") {
                notificationSettings.revokeApplicationInhibitions()
            }
            if ("fullscreenFocused" in notificationSettings) {
                notificationSettings.fullscreenFocused = false
            }
            if ("screensMirrored" in notificationSettings) {
                notificationSettings.screensMirrored = false
            }
        } else {
            const inhibitedUntil = new Date()
            inhibitedUntil.setFullYear(inhibitedUntil.getFullYear() + 1)
            notificationSettings.notificationsInhibitedUntil = inhibitedUntil
        }
        notificationSettings.save()
    }

    function toggleTheme() {
        if (!root.themeAdapter || !root.themeAdapter.toggleMode()) {
            requestSettings("appearance")
        }
    }

    function toggleNightLight() {
        if (!root.nightLightAdapter
                || !root.nightLightAdapter.toggleEnabled()) {
            requestSettings("nightlight")
        }
    }

    function toggleVolumeOsd() {
        if (root.volumeOsdAdapter) {
            root.volumeOsdAdapter.toggleOsd()
        }
    }

    function previewNightLightStrength(strength) {
        if (root.nightLightAdapter) {
            root.nightLightAdapter.previewStrength(strength)
        }
    }

    function setNightLightStrength(strength) {
        if (root.nightLightAdapter) {
            root.nightLightAdapter.setStrength(strength)
        }
    }

    function stopNightLightPreview() {
        if (root.nightLightAdapter) {
            root.nightLightAdapter.stopPreview()
        }
    }

    function requestSettings(section) {
        passwordSurface.closeAndClear()
        pendingApplicationAction = ""
        pendingSettingsSection = String(section || "")
        forceClose()
    }

    function requestApplication(action) {
        passwordSurface.closeAndClear()
        pendingSettingsSection = ""
        pendingApplicationAction = String(action || "")
        forceClose()
    }

    function forceClose() {
        if (!controlCenterOpen && closeTimer.running) {
            return
        }
        passwordSurface.closeAndClear()
        controlCenterOpen = false
        closeTimer.restart()
    }

    function resetOverlay() {
        closeTimer.stop()
        passwordSurface.closeAndClear()
        pendingSettingsSection = ""
        pendingApplicationAction = ""
        currentPage = "home"
        networkSubmenuOpen = false
        networkErrorMessage = ""
        controlCenterOpen = false
    }

    Timer {
        id: closeTimer
        interval: root.animCloseDuration
        repeat: false
        onTriggered: {
            const section = root.pendingSettingsSection
            const application = root.pendingApplicationAction
            root.pendingSettingsSection = ""
            root.pendingApplicationAction = ""
            root.currentPage = "home"
            root.closeFinished()
            if (section.length > 0 && root.controller) {
                Qt.callLater(function() {
                    root.controller.openSettings(section)
                })
            } else if (application.length > 0 && root.controller) {
                Qt.callLater(function() {
                    root.controller.openApplication(application)
                })
            }
        }
    }

    Components.PunchiFullscreenBackdrop {
        id: fullscreenBackdrop
        anchors.fill: parent
        active: root.controlCenterOpen && !root.floatingMode
        blurEnabled: true
        backgroundOpacity: 0.50
        motionEnabled: root.motionEnabled
        openDuration: root.animOpenDuration
        closeDuration: root.animCloseDuration
        onClicked: root.forceClose()
    }

    ControlCenterRightRail {
        id: mainContent
        objectName: "controlCenterMainContent"
        floatingMode: root.floatingMode
        referenceWidth: root.viewportWidth
        referenceHeight: root.viewportHeight
        // Anchored reveal in floating mode: the panel stays opaque and grows out
        // of its docked corner. The full-screen rail keeps the horizontal travel,
        // because scaling a full-height surface would resize its text and leave
        // the mapped blur region at a scale it cannot follow. Both read the same
        // progress, so there is still one surface with one origin.
        opacity: root.floatingMode
            ? RevealMetrics.revealOpacity(root.revealProgress)
            : root.revealProgress
        scale: root.floatingMode
            ? RevealMetrics.revealScale(root.revealProgress,
                root.revealScaleDelta)
            : 1.0
        transformOrigin: root.revealOrigin

        transform: Translate {
            id: surfaceTranslation

            x: root.floatingMode ? 0
                : RevealMetrics.revealTravel(root.revealProgress,
                    Math.max(Kirigami.Units.gridUnit * 4,
                        Math.min(mainContent.width * 0.14,
                            Kirigami.Units.gridUnit * 6)))
        }

        KSvg.FrameSvgItem {
            id: floatingBackground

            anchors.fill: parent
            anchors.leftMargin: -root.themeFrameOverlapLeft
            anchors.topMargin: -root.themeFrameOverlapTop
            anchors.rightMargin: -root.themeFrameOverlapRight
            anchors.bottomMargin: -root.themeFrameOverlapBottom
            imagePath: "widgets/background"
            opacity: root.safeFloatingBackgroundOpacity
            visible: root.floatingMode
            Accessible.ignored: true
        }

        ColumnLayout {
            anchors.fill: parent
            // The theme frame allowance applies to both presentations: the only
            // intended difference between floating and full screen is the
            // backdrop, never the content width, the layout or the number of
            // controls. Applying it only in floating made the full-screen rail
            // wider and the quick-action strip fit one more control.
            anchors.leftMargin: floatingBackground.margins.left
                + Kirigami.Units.largeSpacing
            anchors.topMargin: floatingBackground.margins.top
                + Kirigami.Units.largeSpacing
            anchors.rightMargin: floatingBackground.margins.right
                + Kirigami.Units.largeSpacing
            anchors.bottomMargin: floatingBackground.margins.bottom
                + Kirigami.Units.largeSpacing
            spacing: Kirigami.Units.largeSpacing

            RowLayout {
                Layout.fillWidth: true
                spacing: Kirigami.Units.mediumSpacing

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0

                    Controls.Label {
                        Layout.fillWidth: true
                        text: i18nc("@title", "Control Center") // qmllint disable unqualified
                        font.pointSize: Kirigami.Theme.defaultFont.pointSize * 1.5
                        font.bold: true
                    }

                    Controls.Label {
                        Layout.fillWidth: true
                        // The translation helpers are supplied by the plasmoid context.
                        // qmllint disable unqualified
                        text: root.currentPage === "network"
                            ? i18nc("@info", "Choose and manage a Wi-Fi connection")
                            : root.currentPage === "bluetooth"
                                ? i18nc("@info", "Connect and manage paired Bluetooth devices")
                                : root.currentPage === "sound"
                                    ? i18nc("@info", "Manage audio devices and application volumes")
                                : i18nc("@info", "Quick access to system status and settings")
                        // qmllint enable unqualified
                        opacity: 0.72
                    }
                }

                PlasmaComponents.ToolButton {
                    id: closeButton
                    icon.name: "window-close"
                    text: i18nc("@action:button", "Close") // qmllint disable unqualified
                    display: PlasmaComponents.AbstractButton.IconOnly
                    Accessible.name: text
                    onClicked: root.forceClose()

                    HoverHandler {
                        cursorShape: Qt.PointingHandCursor
                    }
                }
            }

            Item {
                id: pageHost

                Layout.fillWidth: true
                Layout.fillHeight: true

                // One slot per page. The current page expands while the previous
                // one compresses and slides away, so the incoming page lands over
                // the space the outgoing one releases. Both directions and every
                // page use the same declarative transition.
                ControlCenterPageSlot {
                    id: homePageSlot

                    objectName: "controlCenterHomePageSlot"
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    current: root.currentPage === "home"
                    motionEnabled: root.motionEnabled
                    fullHeight: pageHost.height
                    onTransitionFinished: function(current) {
                        if (current) {
                            root.settlePage("home")
                        }
                    }

                    ControlCenterHomePage {
                        id: homePage
                        // The slot clips a plain container and the page root is an
                        // unsized FocusScope, so the page must fill it explicitly.
                        anchors.fill: parent
                        networkSubmenuOpen: root.networkSubmenuOpen
                        networkErrorMessage: root.networkErrorMessage
                        onNetworkSubmenuToggleRequested: {
                            if (root.networkAdapter) {
                                if (!root.networkSubmenuOpen) {
                                    root.networkErrorMessage = ""
                                }
                                root.networkSubmenuOpen = !root.networkSubmenuOpen
                            } else {
                                root.requestSettings("network")
                            }
                        }
                        volumeAdapter: root.volumeAdapter
                        brightnessAdapter: root.brightnessAdapter
                        networkAdapter: root.networkAdapter
                        bluetoothAdapter: root.bluetoothAdapter
                        themeAdapter: root.themeAdapter
                        nightLightAdapter: root.nightLightAdapter
                        volumeOsdAdapter: root.volumeOsdAdapter
                        notificationModel: notificationHistory
                        unreadNotificationCount: root.unreadNotificationCount
                        expiredNotificationCount:
                            notificationHistory.expiredNotificationsCount
                        notificationServiceValid: NotificationManager.Server.valid
                        doNotDisturbAvailable: NotificationManager.Server.valid
                        doNotDisturbActive: root.doNotDisturbActive
                        motionEnabled: root.motionEnabled
                        onNetworkRequested: root.showNetworkPage()
                        onBluetoothRequested: root.showBluetoothPage()
                        onSoundRequested: root.showSoundPage()
                        onDoNotDisturbRequested: root.toggleDoNotDisturb()
                        onThemeToggleRequested: root.toggleTheme()
                        onNightLightToggleRequested: root.toggleNightLight()
                        onVolumeOsdToggleRequested: root.toggleVolumeOsd()
                        onNightLightStrengthPreviewRequested: function(strength) {
                            root.previewNightLightStrength(strength)
                        }
                        onNightLightStrengthPreviewStopped:
                            root.stopNightLightPreview()
                        onNightLightStrengthModified: function(strength) {
                            root.setNightLightStrength(strength)
                        }
                        onNotificationCloseRequested: function(index) {
                            notificationHistory.close(
                                notificationHistory.index(index, 0))
                        }
                        onClearNotificationsRequested: notificationHistory.clear(
                            NotificationManager.Notifications.ClearExpired)
                        onSettingsRequested: function(section) {
                            root.requestSettings(section)
                        }
                        onApplicationRequested: function(application) {
                            root.requestApplication(application)
                        }
                    }
                }

                ControlCenterPageSlot {
                    id: networkPageSlot

                    objectName: "controlCenterNetworkPageSlot"
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    current: root.currentPage === "network"
                    motionEnabled: root.motionEnabled
                    fullHeight: pageHost.height
                    onTransitionFinished: function(current) {
                        if (current) {
                            root.settlePage("network")
                        }
                    }

                    Loader {
                        id: networkPageLoader
                        anchors.fill: parent
                        active: (root.currentPage === "network"
                                || networkPageSlot.progress > 0.001)
                            && root.networkAdapter !== null
                        asynchronous: false
                        sourceComponent: Component {
                            ControlCenterNetworkPage {
                                adapter: root.networkAdapter
                                onBackRequested: root.showHomePage()
                                onSettingsRequested: function(section) {
                                    root.requestSettings(section)
                                }
                            }
                        }
                    }
                }

                ControlCenterPageSlot {
                    id: bluetoothPageSlot

                    objectName: "controlCenterBluetoothPageSlot"
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    current: root.currentPage === "bluetooth"
                    motionEnabled: root.motionEnabled
                    fullHeight: pageHost.height
                    onTransitionFinished: function(current) {
                        if (current) {
                            root.settlePage("bluetooth")
                        }
                    }

                    Loader {
                        id: bluetoothPageLoader
                        anchors.fill: parent
                        // Kept loaded while the slot is still visible so the page
                        // can compress instead of disappearing at once.
                        active: (root.currentPage === "bluetooth"
                                || bluetoothPageSlot.progress > 0.001)
                            && root.bluetoothAdapter !== null
                        asynchronous: false
                        sourceComponent: Component {
                            ControlCenterBluetoothPage {
                                adapter: root.bluetoothAdapter
                                onBackRequested: root.showHomePage()
                                onSettingsRequested: function(section) {
                                    root.requestSettings(section)
                                }
                            }
                        }
                    }
                }

                ControlCenterPageSlot {
                    id: audioPageSlot

                    objectName: "controlCenterAudioPageSlot"
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    current: root.currentPage === "sound"
                    motionEnabled: root.motionEnabled
                    fullHeight: pageHost.height
                    onTransitionFinished: function(current) {
                        if (current) {
                            root.settlePage("sound")
                        }
                    }

                    Loader {
                        id: audioPageLoader
                        anchors.fill: parent
                        active: (root.currentPage === "sound"
                                || audioPageSlot.progress > 0.001)
                            && root.volumeAdapter !== null
                        asynchronous: false
                        sourceComponent: Component {
                            ControlCenterAudioPage {
                                adapter: root.volumeAdapter
                                showVirtualDevices:
                                    root.showVirtualAudioDevices
                                motionEnabled: root.motionEnabled
                                onBackRequested: root.showHomePage()
                                onSettingsRequested: function(section) {
                                    root.requestSettings(section)
                                }
                                onShowVirtualDevicesToggled: function(enabled) {
                                    root.showVirtualAudioDevices = enabled
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    PunchiMenuComponents.PunchiMenuMappedSurfaceGeometry {
        id: mappedSurfaceGeometry

        targetItem: root
        surfaceItem: mainContent
        backgroundItem: floatingBackground
        translationX: surfaceTranslation.x
        translationY: surfaceTranslation.y
        leftInset: floatingBackground.inset.left
        topInset: floatingBackground.inset.top
        rightInset: floatingBackground.inset.right
        bottomInset: floatingBackground.inset.bottom
    }

    Connections {
        target: root.networkAdapter
        enabled: root.networkAdapter !== null

        function onPasswordRequested(network) {
            passwordSurface.openForNetwork(network)
        }

        function onActivationFailed(message) {
            // Keep the error on the home tile after the inline page unloads.
            // While its exit is visible, also show the inline message there.
            if (root.currentPage === "home") {
                root.networkErrorMessage = String(message || "")
                homePage.showNetworkError(message)
            } else if (root.networkPage) {
                root.networkPage.showError(message)
            }
        }
    }

    ControlCenterNetworkPasswordSurface {
        id: passwordSurface
        anchors.fill: parent
        z: 20
        adapter: root.networkAdapter
        motionEnabled: root.motionEnabled
    }
}
