# Checklist de regressão e segurança de release

## 1. Validação prévia (sem instalar)

```bash
node tests-dev/test-v1-release-identity.mjs
node tests-dev/test-r63-7-wheel-tray-only.mjs
bash tests-dev/run-release-regressions.sh
bash scripts-user/setup.sh --help
bash scripts-user/setup.sh --check-deps
```

Os testes da release foram selecionados para cobrir os fluxos vigentes; verificações antigas que exigiam APIs e scripts removidos permanecem apenas no arquivo histórico opcional.

## 2. Compilação (em máquina com KDE Plasma/KF6)

```bash
bash scripts-user/setup.sh --build-only -j 2
bash scripts-user/setup.sh --install --no-restart -j 2
```

Sem ECM e Plasma/KF6 de desenvolvimento, **não é possível homologar** a compilação nem a interface. A instalação não deve apagar dados anteriores ou alterar o ID legado do applet.

## 3. Matriz funcional no Plasma real

- [ ] Instalar/atualizar sobre instalação existente sem perder preferências/ícones.
- [ ] Sobre: versão 1.0.0, nomes em linhas separadas, GitHub/Reddit, ícone correto.
- [ ] Trocar entre 11 categorias sem página anterior visível nem atrasos excessivos.
- [ ] Itens: modelo completo; arraste único/coletivo; seleções com botão direito; menu OgerMenu não removível.
- [ ] Pastas: nomes reais, cores individuais antigas, herança correta de categorias e Aplicar/Cancelar.
- [ ] MEGA e outros autostart SNI: scroll em Firefox/Dolphin não abre popup MEGA (R63.7).
- [ ] Tray temporária: hover não dispara prévia espúria, menu nativo + Voltar para a tray, processo permanece vivo.
- [ ] Leque com vários apps tray, inclusive janelas maximizadas: sem stutter visível.
- [ ] Mini-player: não altera área da dock, controles fixos, só surge quando há áudio real.
- [ ] Lixeira: rodapé fixo, confirmação integrada, cancelamento ao fechar.
- [ ] Idiomas pt_BR/en/es/de, modo claro/escuro do usuário e escala Wayland.

## 4. Critérios de aprovação

1. Distinguir testes automáticos, compilação, instalação e validação visual pelo usuário. Um não substitui outro.
2. Registrar log `journalctl --user` após reproduzir regressão; não inferir apenas por uma captura isolada.
3. Não alterar mais de um subsistema crítico por vez sem testes de isolamento.
4. Manter instruções de rollback e não sobrescrever dados persistidos na atualização.
5. `AGENTS.md` e os documentos de IA são referências para evitar erros, não garantias de ausência de bugs.
