# Official Oger Dock screenshot checklist

Use **real screenshots of Oger Dock 1.0.0** from the user's KDE Plasma session, without artwork copied from another dock. Prefer a consistent resolution/theme and remove personal account names, notifications and private data.

Suggested gallery assets (not yet included):

| Filename | Content | Suggested framing |
|---|---|---|
| `docs/images/oger-dock-main.png` | Main bottom-positioned dock | Wide desktop crop, 16:9 |
| `docs/images/oger-dock-folders.png` | Open fan folder with app icons | Medium detail crop |
| `docs/images/oger-dock-menu.png` | Normal application menu | Full menu, legible labels |
| `docs/images/oger-dock-reduced-menu.png` | Reduced menu | Detail crop |
| `docs/images/oger-dock-player.png` | MPRIS player and expanded info | Detail crop |
| `docs/images/oger-dock-settings.png` | Main configuration screen | Full dialog |
| `docs/images/oger-dock-side.png` | Left or right placement | Portrait screenshot |

Once the files exist in the repository, place a hero image immediately below the introductory links in each README and add a 2-column image gallery in the Screenshots section. Verify every relative path in the GitHub Markdown preview. Do not add fake screenshots to the public README.
