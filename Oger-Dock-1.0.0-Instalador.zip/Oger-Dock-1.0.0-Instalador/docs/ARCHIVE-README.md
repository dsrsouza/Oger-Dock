# Referências históricas externas

O pacote principal foi limpo para instalação. Relatórios de revisões R25–R63.7, antigos testes A/B e scripts de diagnóstico que não são necessários para compilar a versão 1.0.0 foram removidos daqui. Um arquivo separado **Oger-Dock-1.0.0-Historico-Desenvolvimento.zip** contém o material histórico de referência. Os resumos de regressão e as regras para assistentes de IA permanecem **dentro do instalador** em `AGENTS.md` e `docs/IA-*`.

Não execute scripts históricos em instalações atuais sem auditar seus efeitos: várias abordagens antigas foram rejeitadas e substituídas.
