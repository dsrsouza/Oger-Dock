# Mapa técnico para manutenção — Oger Dock 1.0.0

| Área | Arquivos | Invariantes |
|---|---|---|
| Identidade/versão | `metadata.json`, `CMakeLists.txt`, `NOTICE` | Nome público Oger Dock, versão 1.0.0, 2 autores; ID do applet legado; URI QML `org.punchi.dock` |
| Render principal | `contents/ui/main.qml` | Proteger hover de apps temporários; não transformar eventos de ponteiro em ativação indesejada |
| TaskManager e scroll | `contents/ui/components/TaskModelController.qml` | Filtrar candidatos tray-only antes de emitir SNI Activate; scroll sem wrap |
| SNI nativo | `src/traywindowbridge.cpp`, `contents/ui/components/DockContextActionsController.qml` | Menus DBusMenu reais; não iniciar duplicatas; manter SNI quando popup some |
| Config Itens | `contents/ui/config/ConfigItems.qml`, `contents/ui/config/code/configItems.js` | ListModel integral; não reintroduzir timer incremental; Aplicar/Cancelar |
| Config Pastas | `contents/ui/config/ConfigFolderPopups.qml`, `contents/ui/config/code/configFolderRegistry.js`, `contents/ui/components/FolderPopup.qml` | `folderAccentColor` individual / `folderCategoryColorsJson` fallback; cores herdadas identificadas |
| Config visual | `contents/ui/config/ConfigAspect.qml`, `ConfigMenuAppearance.qml`, `ConfigAudioAppearance.qml` e demais páginas | Páginas KCM independentes, `cfg_` persistentes sem duplicação; não construir abas pesadas sem necessidade |
| Layout de menu | `contents/ui/components/punchimenu/`, `src/punchimenulayout*` | Nomes de classe/arquivo históricos são técnicos; UI deve mostrar OgerMenu |
| Compilação | `scripts-user/setup.sh`, `scripts-user/lib/package-plasmoid.sh`, `src/CMakeLists.txt` | `PUNCHI_PACKAGE_CORE=1` + validação minimal na instalação; requer ECM/KF6/Qt6 no host |
| Traduções | `po/en.po`, `po/pt_BR.po`, `po/es.po`, `po/de.po`, `scripts-user/lib/setup-localization.sh` | Domínio histórico preservado; msgids estão em inglês, marca pública deve ser Oger Dock |

O pacote ZIP contém o fonte e os scripts necessários para **compilar localmente**, não um binário Qt6 precompilado. O `.plasmoid` é gerado no próprio computador do usuário pelo instalador.

**Nunca aplicar substituição global de `punchi`**. Há identificadores persistidos em JSON, QML e KDE, além de caminhos antigos de arquivos de configuração do usuário que precisam continuar funcionando.
