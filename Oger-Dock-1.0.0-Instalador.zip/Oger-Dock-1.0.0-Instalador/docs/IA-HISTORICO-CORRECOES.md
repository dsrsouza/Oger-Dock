# Histórico das correções assistidas por IA — Oger Dock

**Base do lançamento:** Oger Dock 1.0.0, derivada da R63.7. Este documento registra decisões, erros detectados e resultados de testes relatados pelo usuário. Não atribui homologação a recursos que não foram testados no Plasma real.

## Linha do tempo de decisões e regressões

| Revisão / período | O que foi observado | Como manter a correção / o que não repetir |
|---|---|---|
| R12–R21 | Scroll pulava aplicativos; menus de tray falhavam, player cortava, indicadores de downloads inconsistentes | Scroll um item por passo, na direção correta, sem looping; menus de tray devem usar SNI/DBusMenu verdadeiros; não reintroduzir download UI inacabada |
| R28 | ZapZap e qBittorrent tiveram menu nativo recuperado | Generalizar por identidade SNI sem hardcode exclusivo e não duplicar instâncias |
| R40–R44 | Leque com engasgos quando vários aplicativos tray estavam ativos. Ensaios isolados SNI/TaskManager não bastaram | Evitar trabalho por frame, polling e recálculos no TaskManager sem medição. Não reintroduzir guardas de desempenho R44 como solução suposta |
| **R45** | Separar aplicativos abertos manualmente e aplicativos autostart trouxe fluidez ao leque | Manter apps do sistema e autostart na bandeja conforme política; apps ativados explicitamente podem ter item temporário; evitar entradas duplicadas |
| **R47–R49** | Leque passou a usar ícones nítidos e menu ficou rápido; indicadores de download removidos | Não reduzir resolução prematuramente; não reintroduzir indicadores de download por conta própria |
| R55–R57 | Tentativas de ajustes para janela restaurada; decisão posterior foi usar configurações em janela maximizada | Não reconstruir múltiplos diálogos com geometrias independentes; seguir layouts responsivos sem cortar conteúdo |
| R62.4–R62.6 | Página Itens sumiu após tentativa de timer/incremental em R62.5 | **R62.6 restaurou ListModel síncrono**; carregar mosaicos das pastas em segundo plano é permitido, mas não deixar lista de Itens vazia |
| R62.7–R62.8 | Categoria Aparência custava ~320 ms; Itens ~160 ms; cargas de abas e animações pesavam | Páginas separadas no `ConfigModel` KDE, `cfg_` no KConfig, sem página inteira animada/StackLayout monolítico. Preservar Aplicar/Cancelar |
| R63.0–R63.1 | Seletores de cor de Pastas sobrepostos, títulos errados | Usar controles nativos, larguras controladas; não usar `contentItem` custom sem medir clamping; legibilidade no tema do usuário |
| **R63.2** | Tentativa de corrigir janela MEGA com script KWin falhou no Wayland; ajuste Qt Wayland moveu popup do canto para o centro, não para ícone | **Estratégia rejeitada.** Removida do instalador na R63.3. Não instalar scripts KWin que movimentem janelas externas, nem forçar posição do popup da tray KDE |
| R63.3 | Promoção de app de tray ao ganhar foco, opção “Voltar para a tray” | Entrada temporária de sessão, sem gravar em pins; SNI verdadeiro mantém ícone mesmo quando popup oculta; ação explícita remove item, não encerra processo |
| **R63.4** | Cores personalizadas não apareciam nas configurações porque só eram lidas cores de categorias | Ler `dockItemsJson` e `folderAccentColor`; listar pastas reais sem confundir homônimas; fallback para 8 categorias somente se não existirem pastas |
| R63.5 | MEGA ainda fechava ao hover apesar de guardas no delegate | Causa: não bastava criar condição, dados foram perdidos entre modelo e delegate |
| **R63.6** | `taskDataForEntry()` descartava `temporaryTrayId`, então o delegate não identificava MEGA temporário | Propagar `temporaryTrayId` em todos os retornos. Guardar `modelData.temporaryTrayId` e fallback em `taskData`. Teste integrado modelo→delegate, não só regex |
| **R63.7** | Scroll navegando Firefox ativava popup MEGA mesmo sem promovê-lo | **Correção aprovada pelo usuário no Plasma real.** Filtrar autostart/tray-only em `wheelCandidates()` (TaskManager e SNI) **antes** de chamar `Activate`; preservar exceções para pin e promoção explícita |

## Incidentes especialmente perigosos

### 1. Confundir SNI com janela gerenciada

O SNI informa que o aplicativo existe na bandeja e permite comandos nativos, **não garante** que seu popup esteja no modelo de tarefas do KWin/Plasma, nem que `Activate(x,y)` imponha posição ou alternância. O clique no ícone de tray do painel do Plasma não é entregue à dock. Script KWin que dependia de `windowAdded`, janela movível, classe, posição do ponteiro e tamanho exatos falhou no teste real.

### 2. Sucesso de teste estático sem fluxo funcional

R63.5 continha proteção contra hover, mas a propriedade `temporaryTrayId` não chegava ao delegate; teste isolado passou e comportamento real falhou. Novos testes devem exercer a extração e projeção do dado real (inclusive fallback), o mouse/hover, o clique e os efeitos resultantes.

### 3. Duplicidade de cores e perda de preferências

A cor de uma pasta personalizada mora no item; a categoria global é um fallback. Exibir a cor global da categoria como se fosse a cor da pasta é erro de semântica, não de estilo visual. Ao atualizar JSON, editar apenas a entrada selecionada; evitar reserializar perda de comandos/ordem/tipos/pins.

### 4. Navegação de configurações aparentemente lenta

Medições reais de R62.6: ~322 ms na Aparência, ~157 ms em Itens. Criar controles de todas as abas ao abrir a categoria repetia trabalho. A solução foi separar páginas, não mascarar com animações. A regressão R62.5 deixou a lista vazia após timer incremental; não repetir.

## Recursos já aprovados que não devem regredir

- Leque fluido, com mosaicos nítidos e sem stutter visível em teste da R45–R49.
- Scroll sequencial preciso, sem wrap, respeitando extremos, alternância restaurar/minimizar e a direção do gesto.
- Apps que iniciam com a sessão na bandeja não entram na sequência de scroll (R63.7 aprovada); aplicativos do sistema mantêm exceções existentes.
- Leque, menu Normal/Reduzido, mini-player de 4 controles fixos e card de texto deslizante, lixeira integrada.
- Ícones individuais de pastas, escolha de cor por pasta e por categoria; itens podem ser arrastados/reordenados na configuração.
- Menu nativo SNI preservado, inclusive ação temporária "Voltar para a tray" sem encerrar o processo.

## Limitações reconhecidas

- Não afirmar que popup de terceiros seguirá o ícone do painel KDE ou que o MEGA sempre obedecerá alternância visível/oculta só porque `Activate` foi enviado.
- Os testes de compilação dependem de ECM, KF6, Qt6 e Plasma reais; offline é possível testar JS/JSON/QML sintaticamente, mas não a renderização Wayland.
- Algumas verificações estruturais de revisões antigas falhavam após arquitetura ser substituída. Não apresentar esse número como falhas do runtime; reavaliar teste a teste e criar novos cenários funcionais.

## Créditos e uso da IA

As revisões foram construídas com auxílio de IA e validadas seletivamente pelo usuário. O assistente não tem acesso automático à máquina do usuário. **Não registrar como homologada uma regressão que só passou em testes simulados.** Preserve a licença e a origem Punchi Dock Remastered mesmo com nome público Oger Dock.
