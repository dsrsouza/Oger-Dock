# Publicação de documentação e suporte — Oger Dock 1.0.0

**Base funcional:** R63.7 (preservada).

- `metadata.json`: o endereço de suporte da aba Informações (`BugReportUrl`) passa a abrir o GitHub Discussions do projeto.
- `tests-dev/test-v1-release-identity.mjs`: expectativa atualizada para o novo link de suporte.
- README principal em inglês e README em português; guias de instalação por distribuição e checklist de capturas reais.
- O instalador continua sendo um pacote **completo de código-fonte para compilação local**, sem binário `.plasmoid` universal.
- Não foram alterados QML, JavaScript funcional, C++, scripts de compilação, ID técnico do plasmoide nem as regras de scroll/SNI da R63.7.
- A página GitHub Discussions precisa ser ativada pelo proprietário do repositório caso esteja desativada.

**Validação:** testes Node, sintaxe Bash e integridade ZIP/TAR.GZ executados na preparação. A compilação nativa no KDE Plasma/Wayland permanece pendente no equipamento-alvo.
