# Histórico de versões públicas do Oger Dock

## 1.0.0 — 2026-11-10

Primeira versão pública **1.0.0** preparada a partir da R63.7.

- Atualizados o nome público, a versão do KPlugin/CMake, o identificador de arquivo gerado pelo instalador e os cabeçalhos de tradução.
- Autores apresentados como duas pessoas independentes na página **Sobre**: **Diego Souza.R** e **Punchisoft**.
- Mantidas as correções aprovadas na R63.7, especialmente o bloqueio da ativação involuntária de apps exclusivos da tray durante o scroll.
- Mantidas configurações de pastas personalizadas, páginas KDE divididas, menus, leque, mini-player e outras funções da base R63.7.
- Preservadas, por compatibilidade, a identidade do plasmoide, as chaves antigas de configurações, o URI do módulo QML e os nomes de classes e tipos persistidos.
- Atualizados os créditos públicos, preservando a atribuição de origem do Punchi Dock Remastered.

### Estado da validação

A alteração 1.0.0 é de **identidade/versão e empacotamento**, não uma reescrita funcional. O comportamento da R63.7 foi aprovado pelo usuário para a correção de scroll/MEGA; não representa homologação automática de todas as funções ou versões futuras do Plasma.

## Revisões de desenvolvimento anteriores

Histórico de revisões R25–R63.7 nos arquivos `HISTORICO_ALTERACOES.md` e `LEIA-ME-R*.md`.

### Preparação final do pacote 1.0.0

- Incluído catálogo inglês `po/en.po` junto aos catálogos pt_BR, es e de; atualização do CMake para compilar as quatro traduções.
- Preparados guias em português e inglês, instruções de instalação local e `RELEASE-MANIFEST.json`.
- Criados `AGENTS.md` e documentos em `docs/IA-*` com decisões aprovadas, tentativas rejeitadas, causas de regressões e checklist de validação para futuras IAs e mantenedores.
- Instalador principal limpo de diagnósticos A/B, relatórios antigos, testes obsoletos e rotinas KWin descartadas. Arquivo histórico separado para auditoria, sem interferir na instalação.
- Mantido o código funcional R63.7 com o filtro de scroll de aplicativos exclusivos da tray, já aprovado pelo usuário. Não foram renomeados IDs técnicos persistidos.
